package com.axis.movie.confi;

public class WebSecurityConfig {

}
