package com.axis.movie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieTicketBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
